﻿using Volo.Abp.Application.Services;

namespace Meowv.Blog
{
    public class ServiceBase : ApplicationService
    {
    }
}