﻿namespace Meowv.Blog.Caching.Blog.Impl
{
    public partial class BlogCacheService : CachingServiceBase, IBlogCacheService
    {
    }
}