﻿namespace Meowv.Blog.Caching.Blog
{
    public partial interface IBlogCacheService : ICacheRemoveService
    {
    }
}