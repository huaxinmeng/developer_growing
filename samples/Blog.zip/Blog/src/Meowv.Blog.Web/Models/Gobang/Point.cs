﻿namespace Meowv.Blog.Web.Models.Gobang
{
    public struct Point
    {
        public int Row { get; set; }
        public int Cell { get; set; }
    }
}