﻿namespace Meowv.Blog.Web.Models.Gobang
{
    public class ValuedPoint
    {
        public Point Point { get; set; }

        public int Score { get; set; }
    }
}