﻿namespace Meowv.Blog.Response
{
    public interface IHasTotalCount
    {
        int Total { get; set; }
    }
}