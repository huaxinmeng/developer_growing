﻿namespace Meowv.Blog.Response
{
    public enum BlogResponseCode : int
    {
        Succeed,
        Failed
    }
}