﻿namespace Meowv.Blog.Dto.Blog.Params
{
    public class UpdateFriendLinkInput : CreateFriendLinkInput
    {
    }
}