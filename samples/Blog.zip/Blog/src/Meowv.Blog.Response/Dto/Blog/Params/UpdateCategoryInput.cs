﻿namespace Meowv.Blog.Dto.Blog.Params
{
    public class UpdateCategoryInput : CreateCategoryInput
    {
    }
}