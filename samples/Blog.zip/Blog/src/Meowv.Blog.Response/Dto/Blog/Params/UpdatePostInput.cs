﻿namespace Meowv.Blog.Dto.Blog.Params
{
    public class UpdatePostInput : CreatePostInput
    {
    }
}