﻿namespace Meowv.Blog.Dto.Blog.Params
{
    public class CreateFriendLinkInput
    {
        public string Name { get; set; }

        public string Url { get; set; }
    }
}