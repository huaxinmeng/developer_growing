﻿namespace Meowv.Blog.Dto.Blog.Params
{
    public class CreateCategoryInput
    {
        public string Name { get; set; }

        public string Alias { get; set; }
    }
}