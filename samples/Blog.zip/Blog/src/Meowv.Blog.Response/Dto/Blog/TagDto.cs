﻿namespace Meowv.Blog.Dto.Blog
{
    public class TagDto
    {
        public string Name { get; set; }

        public string Alias { get; set; }
    }
}