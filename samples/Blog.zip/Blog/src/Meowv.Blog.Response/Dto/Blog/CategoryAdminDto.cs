﻿namespace Meowv.Blog.Dto.Blog
{
    public class CategoryAdminDto : CategoryDto
    {
        public string Id { get; set; }
    }
}