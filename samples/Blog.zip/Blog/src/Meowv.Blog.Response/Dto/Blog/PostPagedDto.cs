﻿namespace Meowv.Blog.Dto.Blog
{
    public class PostPagedDto
    {
        public string Title { get; set; }

        public string Url { get; set; }
    }
}