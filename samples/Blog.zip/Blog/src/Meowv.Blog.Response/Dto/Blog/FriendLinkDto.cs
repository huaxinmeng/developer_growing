﻿namespace Meowv.Blog.Dto.Blog
{
    public class FriendLinkDto
    {
        public string Name { get; set; }

        public string Url { get; set; }
    }
}