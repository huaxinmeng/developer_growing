﻿namespace Meowv.Blog.Dto.Blog
{
    public class GetAdminTagDto : GetTagDto
    {
        public string Id { get; set; }
    }
}