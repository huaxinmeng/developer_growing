﻿namespace Meowv.Blog.Dto.Blog
{
    public class GetTagDto : TagDto
    {
        public int Total { get; set; }
    }
}