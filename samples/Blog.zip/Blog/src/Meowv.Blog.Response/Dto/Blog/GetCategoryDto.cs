﻿namespace Meowv.Blog.Dto.Blog
{
    public class GetCategoryDto : CategoryDto
    {
        public int Total { get; set; }
    }
}