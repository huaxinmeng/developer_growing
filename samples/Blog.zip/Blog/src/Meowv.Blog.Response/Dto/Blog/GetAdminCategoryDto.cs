﻿namespace Meowv.Blog.Dto.Blog
{
    public class GetAdminCategoryDto : GetCategoryDto
    {
        public string Id { get; set; }
    }
}