﻿namespace Meowv.Blog.Dto.Blog
{
    public class CategoryDto
    {
        public string Name { get; set; }

        public string Alias { get; set; }
    }
}