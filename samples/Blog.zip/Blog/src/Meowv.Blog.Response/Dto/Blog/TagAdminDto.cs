﻿namespace Meowv.Blog.Dto.Blog
{
    public class TagAdminDto : TagDto
    {
        public string Id { get; set; }
    }
}