﻿namespace Meowv.Blog.Dto.Blog
{
    public class GetAdminFriendLinkDto : FriendLinkDto
    {
        public string Id { get; set; }
    }
}