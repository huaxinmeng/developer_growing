﻿namespace Meowv.Blog.Dto.Authorize.Params
{
    public class AccountInput
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}