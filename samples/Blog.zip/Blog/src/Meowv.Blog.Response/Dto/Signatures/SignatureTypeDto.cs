﻿namespace Meowv.Blog.Dto.Signatures
{
    public class SignatureTypeDto
    {
        public string Type { get; set; }

        public int TypeId { get; set; }
    }
}