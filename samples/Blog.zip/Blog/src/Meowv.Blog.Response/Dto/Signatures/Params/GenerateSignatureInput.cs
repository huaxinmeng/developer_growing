﻿namespace Meowv.Blog.Dto.Signatures.Params
{
    public class GenerateSignatureInput
    {
        public string Name { get; set; }

        public int TypeId { get; set; }
    }
}