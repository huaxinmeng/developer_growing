﻿namespace Meowv.Blog.Dto.Users.Params
{
    public class UpdateUserinput
    {
        public string Username { get; set; }

        public string Name { get; set; }

        public string Avatar { get; set; }

        public string Email { get; set; }
    }
}