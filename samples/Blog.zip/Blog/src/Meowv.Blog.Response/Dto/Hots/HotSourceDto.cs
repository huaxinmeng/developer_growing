﻿namespace Meowv.Blog.Dto.Hots
{
    public class HotSourceDto
    {
        public string Id { get; set; }

        public string Source { get; set; }
    }
}