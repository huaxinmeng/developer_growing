﻿namespace Meowv.Blog.Dto.Sayings
{
    public class SayingDto
    {
        public string Id { get; set; }

        public string Content { get; set; }
    }
}