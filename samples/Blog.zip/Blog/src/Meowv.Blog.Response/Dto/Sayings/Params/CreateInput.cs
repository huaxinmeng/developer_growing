﻿using System.Collections.Generic;

namespace Meowv.Blog.Dto.Sayings.Params
{
    public class CreateInput
    {
        public List<string> Content { get; set; }
    }
}