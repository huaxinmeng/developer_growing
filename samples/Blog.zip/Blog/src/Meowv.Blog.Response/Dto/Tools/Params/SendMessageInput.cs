﻿namespace Meowv.Blog.Dto.Tools.Params
{
    public class SendMessageInput
    {
        public string Text { get; set; }

        public string Desc { get; set; }
    }
}