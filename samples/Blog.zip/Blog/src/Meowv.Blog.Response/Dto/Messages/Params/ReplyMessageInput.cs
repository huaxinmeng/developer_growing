﻿namespace Meowv.Blog.Dto.Messages.Params
{
    public class ReplyMessageInput : CreateMessageInput
    {
    }
}