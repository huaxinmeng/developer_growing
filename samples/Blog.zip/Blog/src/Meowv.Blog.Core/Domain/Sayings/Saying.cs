﻿namespace Meowv.Blog.Domain.Sayings
{
    public class Saying : EntityBase
    {
        public string Content { get; set; }
    }
}