﻿namespace Meowv.Blog.EventData.Hots
{
    public class HotWorkerEventData
    {
    }
}