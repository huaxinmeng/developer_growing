﻿namespace Meowv.Blog.Options
{
    public class TencentCloudOptions
    {
        public string SecretId { get; set; }

        public string SecretKey { get; set; }
    }
}