﻿using Abp.Authorization;
using selfProject.Authorization.Roles;
using selfProject.Authorization.Users;

namespace selfProject.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
