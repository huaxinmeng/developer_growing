﻿using selfProject.Debugging;

namespace selfProject
{
    public class selfProjectConsts
    {
        public const string LocalizationSourceName = "selfProject";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;


        /// <summary>
        /// Default pass phrase for SimpleStringCipher decrypt/encrypt operations
        /// </summary>
        public static readonly string DefaultPassPhrase =
            DebugHelper.IsDebug ? "gsKxGZ012HLL3MI5" : "3a97ffb9f4bf4431aff45858bf005dd8";
    }
}
