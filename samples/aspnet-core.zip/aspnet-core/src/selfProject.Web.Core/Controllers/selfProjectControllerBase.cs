using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using Microsoft.AspNetCore.Identity;

namespace selfProject.Controllers
{
    public abstract class selfProjectControllerBase: AbpController
    {
        protected selfProjectControllerBase()
        {
            LocalizationSourceName = selfProjectConsts.LocalizationSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}
