using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace selfProject.EntityFrameworkCore
{
    public static class selfProjectDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<selfProjectDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<selfProjectDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
