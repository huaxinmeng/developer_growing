﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using selfProject.Authorization.Roles;
using selfProject.Authorization.Users;
using selfProject.MultiTenancy;

namespace selfProject.EntityFrameworkCore
{
    public class selfProjectDbContext : AbpZeroDbContext<Tenant, Role, User, selfProjectDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public selfProjectDbContext(DbContextOptions<selfProjectDbContext> options)
            : base(options)
        {
        }
    }
}
