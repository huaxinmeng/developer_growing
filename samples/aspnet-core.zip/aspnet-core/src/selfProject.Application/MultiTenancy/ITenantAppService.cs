﻿using Abp.Application.Services;
using selfProject.MultiTenancy.Dto;

namespace selfProject.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

