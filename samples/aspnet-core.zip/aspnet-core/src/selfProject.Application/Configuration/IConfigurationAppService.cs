﻿using System.Threading.Tasks;
using selfProject.Configuration.Dto;

namespace selfProject.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
