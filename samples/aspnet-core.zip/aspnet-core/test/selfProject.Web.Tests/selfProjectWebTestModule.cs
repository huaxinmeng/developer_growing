﻿using Abp.AspNetCore;
using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using selfProject.EntityFrameworkCore;
using selfProject.Web.Startup;
using Microsoft.AspNetCore.Mvc.ApplicationParts;

namespace selfProject.Web.Tests
{
    [DependsOn(
        typeof(selfProjectWebMvcModule),
        typeof(AbpAspNetCoreTestBaseModule)
    )]
    public class selfProjectWebTestModule : AbpModule
    {
        public selfProjectWebTestModule(selfProjectEntityFrameworkModule abpProjectNameEntityFrameworkModule)
        {
            abpProjectNameEntityFrameworkModule.SkipDbContextRegistration = true;
        } 
        
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(selfProjectWebTestModule).GetAssembly());
        }
        
        public override void PostInitialize()
        {
            IocManager.Resolve<ApplicationPartManager>()
                .AddApplicationPartsIfNotAddedBefore(typeof(selfProjectWebMvcModule).Assembly);
        }
    }
}